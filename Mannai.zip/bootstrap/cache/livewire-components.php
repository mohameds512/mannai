<?php return array (
  'layouts.base' => 'App\\Http\\Livewire\\Layouts\\Base',
  'users-c-r-u-d.add-user-component' => 'App\\Http\\Livewire\\UsersCRUD\\AddUserComponent',
  'users-c-r-u-d.edit-user-component' => 'App\\Http\\Livewire\\UsersCRUD\\EditUserComponent',
  'users-c-r-u-d.index-component' => 'App\\Http\\Livewire\\UsersCRUD\\IndexComponent',
);