<!DOCTYPE html>
<html lang="en">
<head>

    <title>Mannai - task</title>
    <livewire:styles />
</head>
<body>

    {{$slot}}

    <livewire:scripts />
</body>
</html>
