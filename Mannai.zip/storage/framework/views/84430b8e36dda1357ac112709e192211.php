<!DOCTYPE html>
<html lang="en">
<head>

    <title>Mannai - task</title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>

    <?php echo e($slot); ?>


    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\Mannai\resources\views/livewire/layouts/base.blade.php ENDPATH**/ ?>