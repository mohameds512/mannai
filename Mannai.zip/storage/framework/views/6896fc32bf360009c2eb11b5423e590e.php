<div>
    <h1>add user</h1>
</div>
<?php /**PATH C:\laragon\www\Mannai\resources\views/livewire/usercrud/add-user-component.blade.php ENDPATH**/ ?>