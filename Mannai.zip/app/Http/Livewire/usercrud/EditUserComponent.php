<?php

namespace App\Http\Livewire\usercrud;

use Livewire\Component;

class EditUserComponent extends Component
{
    public function render()
    {
        return view('livewire.usercrud.edit-user-component');
    }
}
