<?php

namespace App\Http\Livewire\usercrud;

use Livewire\Component;
use App\Models\User;
class IndexComponent extends Component
{
    public $isOpen = false;
    public $user_id;
    public function render()
    {
        $users = User::all();
        return view('livewire.usercrud.index-component', [
            'users' => $users,
            'isOpen' => $this->isOpen,
            'user_id' => $this->user_id,
            ])->layout('livewire.layouts.base');
    }

    public function create()
    {
        
        $this->resetInputFields();
        $this->openModal();
    }
    public function openModal()
    {
        $this->isOpen = true;
    }

    public function closeModal()
    {
        $this->isOpen = false;
    }
    private function resetInputFields(){
        $this->name = '';
        $this->grade = '';
        $this->department = '';
    }
    public function store()
    {
        $this->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email,'.$this->user_id,
        ]);

        User::updateOrCreate(['id' => $this->user_id], [
            'name' => $this->name,
            'email' => $this->email
        ]);

        session()->flash('message',
            $this->user_id ? 'User Updated Successfully.' : 'User Created Successfully.');

        $this->closeModal();
        $this->resetInputFields();
    }
    public function edit($id)
    {
        $user = User::findOrFail($id);
        $this->user_id = $id;
        $this->name = $user->name;
        $this->email = $user->email;

        $this->openModal();
    }

    public function delete($id)
    {
        User::find($id)->delete();
        session()->flash('message', 'User Deleted Successfully.');
    }
}
